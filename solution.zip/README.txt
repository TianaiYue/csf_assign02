list team members, document who did what, discuss
anything interesting about your implementation.

Team members: Cassie Zhang xzhan304, Tianai Yue tyue4

Milestone 1
Both Cassie and Tianai did relatively equal amounts of work and effort.
Tianai implemented draw_circle, draw_tile, draw_sprite, and test cases for all the functions.
Cassie implemented draw_pixel, draw_rect, helper functions, and test cases for all the functions.

